import subprocess
import threading
import customtkinter as ctk
import os
import sys
import tempfile
import queue
import shutil
import signal
from tkinter import filedialog, messagebox
from datetime import datetime

VERSION = "1.1.4"
DOWNLOAD_HISTORY_FILE = "history/downloads.log"

# Path configurations
def resource_path(relative_path):
    """Get absolute path to resource, works for dev and PyInstaller"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.abspath(relative_path)

EXEC_DIR = resource_path("bin")
yt_dlp_path = resource_path(os.path.join("bin", "yt-dlp.exe"))
aria2c_path = resource_path(os.path.join("bin", "aria2-1.37.0-win-64bit-build1", "aria2c.exe"))
ffmpeg_path = resource_path(os.path.join("bin", "ffmpeg-master-latest-win64-gpl", "bin", "ffmpeg.exe"))

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class YTDownloaderApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"YouTube Downloader {VERSION}")
        self.geometry("800x600")
        self.resizable(False, False)
        
        # Initialize variables
        self.download_path = os.path.expanduser("~/Downloads")
        self.download_process = None
        self.is_paused = False
        self.should_cancel = False
        self.output_queue = queue.Queue()
        self.temp_dir = None
        
        # Setup UI
        self.create_widgets()
        
        # Start output processor
        self.after(100, self.process_output)

    def create_widgets(self):
        # Header with theme toggle
        self.header_frame = ctk.CTkFrame(self, height=40, fg_color="transparent")
        self.header_frame.pack(fill="x", padx=10, pady=5)
        self.theme_button = ctk.CTkButton(
            self.header_frame, text="Dark🌜", width=30, height=30,
            command=lambda: ctk.set_appearance_mode("Light" if ctk.get_appearance_mode() == "Dark" else "Dark"),
            fg_color="transparent", hover=False
        )
        self.theme_button.pack(side="right", padx=5)
        
        # URL Entry
        self.url_label = ctk.CTkLabel(self, text="YouTube URL:")
        self.url_label.pack(pady=(10, 5))
        self.url_entry = ctk.CTkEntry(self, width=700, placeholder_text="https://youtube.com/...")
        self.url_entry.pack(pady=(0, 10))
        
        # Options Frame
        self.option_frame = ctk.CTkFrame(self)
        self.option_frame.pack(pady=(0, 10), fill="x", padx=20)
        self.option_menu = ctk.CTkOptionMenu(self.option_frame, values=["Single Video", "Full Playlist"])
        self.option_menu.pack(side="left", padx=(0, 10))
        self.quality_menu = ctk.CTkOptionMenu(self.option_frame, values=["Best", "1080p", "720p", "480p", "Audio Only"])
        self.quality_menu.pack(side="left")
        
        # Action Buttons
        self.button_frame = ctk.CTkFrame(self)
        self.button_frame.pack(pady=(0, 10), fill="x", padx=20)
        self.folder_button = ctk.CTkButton(self.button_frame, text="📁 Folder", command=self.choose_folder, width=100)
        self.folder_button.pack(side="left", padx=(0, 10))
        self.download_button = ctk.CTkButton(self.button_frame, text="🚀 Download", command=self.start_download)
        self.download_button.pack(side="left", padx=(0, 10))
        self.pause_button = ctk.CTkButton(self.button_frame, text="⏸️ Pause", command=self.toggle_pause, width=100, state="disabled")
        self.pause_button.pack(side="left", padx=(0, 10))
        self.cancel_button = ctk.CTkButton(self.button_frame, text="❌ Cancel", command=self.cancel_download, width=100, state="disabled")
        self.cancel_button.pack(side="left")
        
        # Status Display
        self.status_box = ctk.CTkTextbox(self, height=250, width=750)
        self.status_box.pack(pady=(10, 0))
        self.status_box.insert("end", "Ready to download...\n")
        self.status_box.configure(state="disabled")
        
        # Progress bar
        self.progress_bar = ctk.CTkProgressBar(self, width=750)
        self.progress_bar.pack(pady=(10, 0))
        self.progress_bar.set(0)
        
        # Stats display
        self.stats_frame = ctk.CTkFrame(self, height=30)
        self.stats_frame.pack(fill="x", pady=(5, 0))
        self.speed_label = ctk.CTkLabel(self.stats_frame, text="Speed: -", width=150)
        self.speed_label.pack(side="left", padx=10)
        self.eta_label = ctk.CTkLabel(self.stats_frame, text="ETA: -", width=150)
        self.eta_label.pack(side="left", padx=10)
        self.size_label = ctk.CTkLabel(self.stats_frame, text="Size: -", width=150)
        self.size_label.pack(side="left", padx=10)

    def start_download(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a YouTube URL")
            return
        if self.download_process and self.download_process.poll() is None:
            messagebox.showwarning("Warning", "A download is already in progress")
            return
        self.should_cancel = False
        self.is_paused = False
        self.update_status("🔄 Starting download...\n")
        threading.Thread(target=self.run_download, args=(url,), daemon=True).start()
        self.download_button.configure(state="disabled")
        self.pause_button.configure(state="normal")
        self.cancel_button.configure(state="normal")

    def run_download(self, url):
        try:
            self.temp_dir = tempfile.mkdtemp()
            # Verify binaries exist
            for binary in [yt_dlp_path, aria2c_path, ffmpeg_path]:
                if not os.path.exists(binary):
                    self.output_queue.put(f"❌ Error: Binary not found: {binary}")
                    return
            command = self.build_command(url)
            self.update_status(f"Executing command: {' '.join(command)}\n")
            self.download_process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                encoding='utf-8', errors='replace', bufsize=1, universal_newlines=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            while True:
                if self.should_cancel:
                    break
                line = self.download_process.stdout.readline()
                if not line:
                    if self.download_process.poll() is not None:
                        break
                    continue
                self.output_queue.put(line.strip())
            if self.download_process.poll() == 0:
                self.output_queue.put("✅ Download completed successfully!")
                self.log_history(url, self.download_path)
            else:
                self.output_queue.put(f"❌ Download failed with code {self.download_process.poll()}")
        except Exception as e:
            self.output_queue.put(f"❌ Error: {str(e)}")
        finally:
            self.cleanup_download()

    def build_command(self, url):
        mode = self.option_menu.get()
        quality = self.quality_menu.get()
        playlist_flag = "--yes-playlist" if "Playlist" in mode else "--no-playlist"
        format_flag = ["-f", "bestaudio[ext=m4a]"] if quality == "Audio Only" else \
                     ["-f", f"bestvideo[vcodec^=avc1][height<={quality[:-1]}][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]"] if quality != "Best" else \
                     ["-f", "bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]"]
        output_template = os.path.join(self.download_path, "%(playlist_title)s", "%(playlist_index)s - %(title)s.%(ext)s") if "Playlist" in mode else \
                         os.path.join(self.download_path, "%(title)s.%(ext)s")
        output_template = output_template.replace('"', '\\"')
        aria2c_args = '-x16 -s16 --file-allocation=none --min-split-size=1M --disk-cache=256M --retry-wait=1 --max-tries=15'
        downloader_args = ['--external-downloader', aria2c_path, '--external-downloader-args', aria2c_args]
        return [
            yt_dlp_path, '--ignore-errors', '--retries', '10', '--socket-timeout', '5',
            '--concurrent-fragments', '16', '--no-check-certificate', playlist_flag,
            *format_flag, '--merge-output-format', 'mp4', '--ffmpeg-location', ffmpeg_path,
            *downloader_args, '--embed-subs', '--embed-metadata', '-o', output_template, url
        ]

    def process_output(self):
        try:
            while not self.output_queue.empty():
                line = self.output_queue.get_nowait()
                self.status_box.configure(state="normal")
                self.status_box.insert("end", line + "\n")
                self.status_box.see("end")
                self.status_box.configure(state="disabled")
                if line.startswith("[download]"):
                    try:
                        if "%" in line and "of" in line:
                            percent = float(line.split("%")[0].split()[-1])
                            self.progress_bar.set(percent / 100)
                        if "at" in line and "ETA" in line:
                            speed = line.split("at")[1].split("ETA")[0].strip()
                            self.speed_label.configure(text=f"Speed: {speed}")
                        if "ETA" in line:
                            eta = line.split("ETA")[1].strip()
                            self.eta_label.configure(text=f"ETA: {eta}")
                        if "of" in line and "at" in line:
                            size = line.split("of")[1].split("at")[0].strip()
                            self.size_label.configure(text=f"Size: {size}")
                    except:
                        pass
        except queue.Empty:
            pass
        self.after(100, self.process_output)

    def toggle_pause(self):
        if self.is_paused:
            if self.download_process:
                self.is_paused = False
                self.download_process.send_signal(signal.SIGCONT if os.name != 'nt' else signal.CTRL_BREAK_EVENT)
                self.pause_button.configure(text="⏸️ Pause")
                self.update_status("▶️ Download resumed\n")
        else:
            if self.download_process:
                self.is_paused = True
                self.download_process.send_signal(signal.SIGSTOP if os.name != 'nt' else signal.CTRL_BREAK_EVENT)
                self.pause_button.configure(text="▶️ Resume")
                self.update_status("⏸️ Download paused\n")

    def cancel_download(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to cancel the download?"):
            self.should_cancel = True
            if self.download_process:
                self.download_process.terminate()
                try:
                    self.download_process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.download_process.kill()
            self.update_status("❌ Download cancelled\n")
            self.cleanup_download()

    def cleanup_download(self):
        if self.download_process:
            try:
                self.download_process.terminate()
                self.download_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.download_process.kill()
            self.download_process = None
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
            self.temp_dir = None
        self.download_button.configure(state="normal")
        self.pause_button.configure(state="disabled", text="⏸️ Pause")
        self.cancel_button.configure(state="disabled")
        self.progress_bar.set(0)
        self.speed_label.configure(text="Speed: -")
        self.eta_label.configure(text="ETA: -")
        self.size_label.configure(text="Size: -")

    def update_status(self, message):
        self.output_queue.put(message)

    def log_history(self, url, path):
        try:
            history_file = resource_path(DOWNLOAD_HISTORY_FILE)
            os.makedirs(os.path.dirname(history_file), exist_ok=True)
            with open(history_file, "a", encoding="utf-8") as log:
                log.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {url} → {path}\n")
        except Exception as e:
            self.update_status(f"❌ Error writing to history: {str(e)}")

    def choose_folder(self):
        folder_selected = filedialog.askdirectory(initialdir=self.download_path)
        if folder_selected:
            self.download_path = folder_selected
            self.update_status(f"📂 Download folder set to: {self.download_path}\n")

    def on_closing(self):
        self.cancel_download()
        self.destroy()

if __name__ == "__main__":
    app = YTDownloaderApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()

# import subprocess
# import threading
# import customtkinter as ctk
# import os
# import shutil
# import time
# import requests
# from tkinter import filedialog, messagebox
# from datetime import datetime
# import sys
# import signal
# import tempfile
# import queue
# import json

# VERSION = "1.1.4"  # Updated version for optimized build
# DOWNLOAD_HISTORY_FILE = "history/downloads.log"

# # Enhanced resource path handling for PyInstaller
# def resource_path(relative_path):
#     """Get absolute path to resource, works for dev and PyInstaller"""
#     try:
#         base_path = sys._MEIPASS  # PyInstaller temp directory
#     except AttributeError:
#         base_path = os.path.abspath(".")
#     return os.path.join(base_path, relative_path)

# # Path configurations
# EXEC_DIR = resource_path("bin")
# yt_dlp_path = resource_path(os.path.join("bin", "yt-dlp.exe"))
# aria2c_path = resource_path(os.path.join("bin", "aria2-1.37.0-win-64bit-build1", "aria2c.exe"))
# ffmpeg_path = resource_path(os.path.join("bin", "ffmpeg-master-latest-win64-gpl", "bin", "ffmpeg.exe"))

# ctk.set_appearance_mode("System")
# ctk.set_default_color_theme("blue")

# class YTDownloaderApp(ctk.CTk):
#     def __init__(self):
#         super().__init__()
#         self.title(f"🎮 YouTube Downloader {VERSION}")
#         self.geometry("800x600")
#         self.resizable(False, False)
        
#         # Initialize variables
#         self.download_path = os.path.expanduser("~/Downloads")
#         self.current_theme = ctk.get_appearance_mode()
#         self.download_process = None
#         self.is_paused = False
#         self.should_cancel = False
#         self.active_download_thread = None
#         self.output_queue = queue.Queue()
#         self.temp_dir = None
#         self.use_aria2c_var = ctk.BooleanVar(value=True)  # Toggle for aria2c
        
#         # Setup UI
#         self.create_widgets()
        
#         # Verify binaries
#         self.verify_binaries()
        
#         # Ensure directories exist
#         os.makedirs(os.path.dirname(resource_path(DOWNLOAD_HISTORY_FILE)), exist_ok=True)
        
#         # Start output processor
#         self.after(200, self.process_output)  # Increased interval to reduce GUI overhead

#     def create_widgets(self):
#         """Initialize all UI components"""
#         # Header with theme toggle
#         self.header_frame = ctk.CTkFrame(self, height=40, fg_color="transparent")
#         self.header_frame.pack(fill="x", padx=10, pady=5)
        
#         self.theme_button = ctk.CTkButton(
#             self.header_frame,
#             text="Light🌞" if self.current_theme == "Light" else "Dark🌜",
#             width=30,
#             height=30,
#             command=self.toggle_theme,
#             fg_color="transparent",
#             hover=False
#         )
#         self.theme_button.pack(side="right", padx=5)
        
#         # URL Entry
#         self.url_label = ctk.CTkLabel(self, text="YouTube URL:")
#         self.url_label.pack(pady=(10, 5))
#         self.url_entry = ctk.CTkEntry(self, width=700, placeholder_text="https://youtube.com/...")
#         self.url_entry.pack(pady=(0, 10))
        
#         # Options Frame
#         self.option_frame = ctk.CTkFrame(self)
#         self.option_frame.pack(pady=(0, 10), fill="x", padx=20)
        
#         self.option_menu = ctk.CTkOptionMenu(self.option_frame, values=["Single Video", "Full Playlist"])
#         self.option_menu.pack(side="left", padx=(0, 10))
        
#         self.quality_menu = ctk.CTkOptionMenu(self.option_frame, 
#                                            values=["Best", "1080p", "720p", "480p", "Audio Only"])
#         self.quality_menu.pack(side="left")
        
#         self.aria2c_toggle = ctk.CTkCheckBox(self.option_frame, text="Use aria2c", variable=self.use_aria2c_var)
#         self.aria2c_toggle.pack(side="left", padx=(10, 0))
        
#         # Connection Control
#         self.conn_frame = ctk.CTkFrame(self)
#         self.conn_frame.pack(pady=(0, 10), fill="x", padx=20)
        
#         self.connections_slider = ctk.CTkSlider(self.conn_frame, from_=1, to=16, number_of_steps=15)  # Increased to 32
#         self.connections_slider.set(16)  # Default to 16 for stability
#         self.connections_slider.pack(side="left", expand=True, fill="x", padx=(0, 10))
        
#         self.connections_label = ctk.CTkLabel(self.conn_frame, text="Connections: 16", width=100)
#         self.connections_label.pack(side="left")
#         self.connections_slider.configure(command=lambda v: self.connections_label.configure(text=f"Connections: {int(v)}"))
        
#         # Action Buttons
#         self.button_frame = ctk.CTkFrame(self)
#         self.button_frame.pack(pady=(0, 10), fill="x", padx=20)
        
#         self.folder_button = ctk.CTkButton(self.button_frame, text="📁 Folder", 
#                                          command=self.choose_folder, width=100)
#         self.folder_button.pack(side="left", padx=(0, 10))
        
#         self.download_button = ctk.CTkButton(self.button_frame, text="🚀 Download", 
#                                           command=self.start_download)
#         self.download_button.pack(side="left", padx=(0, 10))
        
#         self.pause_button = ctk.CTkButton(self.button_frame, text="⏸️ Pause", 
#                                        command=self.toggle_pause, width=100, state="disabled")
#         self.pause_button.pack(side="left", padx=(0, 10))
        
#         self.cancel_button = ctk.CTkButton(self.button_frame, text="❌ Cancel", 
#                                         command=self.cancel_download, width=100, state="disabled")
#         self.cancel_button.pack(side="left")
        
#         # Status Display
#         self.status_box = ctk.CTkTextbox(self, height=250, width=750)
#         self.status_box.pack(pady=(10, 0))
#         self.status_box.insert("end", "Ready to download...\n")
#         self.status_box.configure(state="disabled")
        
#         # Progress bar
#         self.progress_bar = ctk.CTkProgressBar(self, width=750)
#         self.progress_bar.pack(pady=(10, 0))
#         self.progress_bar.set(0)
        
#         # Stats display
#         self.stats_frame = ctk.CTkFrame(self, height=30)
#         self.stats_frame.pack(fill="x", pady=(5, 0))
        
#         self.speed_label = ctk.CTkLabel(self.stats_frame, text="Speed: -", width=150)
#         self.speed_label.pack(side="left", padx=10)
        
#         self.eta_label = ctk.CTkLabel(self.stats_frame, text="ETA: -", width=150)
#         self.eta_label.pack(side="left", padx=10)
        
#         self.size_label = ctk.CTkLabel(self.stats_frame, text="Size: -", width=150)
#         self.size_label.pack(side="left", padx=10)

#     def verify_binaries(self):
#         """Verify all required binaries exist and check versions"""
#         missing = []
#         for name, path in [("yt-dlp", yt_dlp_path), 
#                           ("aria2c", aria2c_path),
#                           ("ffmpeg", ffmpeg_path)]:
#             print(f"Checking {name} at {path}: {'exists' if os.path.exists(path) else 'missing'}")
#             if not os.path.exists(path):
#                 missing.append(name)
        
#         if missing:
#             messagebox.showerror("Missing Binaries", 
#                                f"Required binaries missing: {', '.join(missing)}\n"
#                                f"Please ensure they are in the bin folder")
#             self.download_button.configure(state="disabled")
#             return
        
#         # Check yt-dlp version
#         try:
#             result = subprocess.run([yt_dlp_path, '--version'], capture_output=True, text=True)
#             self.update_status(f"yt-dlp version: {result.stdout.strip()}\n")
#         except Exception as e:
#             self.update_status(f"⚠️ Error checking yt-dlp version: {str(e)}\n")
        
#         # Check aria2c version
#         try:
#             result = subprocess.run([aria2c_path, '--version'], capture_output=True, text=True)
#             self.update_status(f"aria2c version: {result.stdout.splitlines()[0]}\n")
#         except Exception as e:
#             self.update_status(f"⚠️ Error checking aria2c version: {str(e)}\n")

#     def toggle_theme(self):
#         """Switch between light/dark theme"""
#         new_theme = "Dark" if ctk.get_appearance_mode() == "Light" else "Light"
#         ctk.set_appearance_mode(new_theme)
#         self.theme_button.configure(text="Light🌞" if new_theme == "Light" else "Dark🌜")
#         self.current_theme = new_theme
#         self.update_status(f"Theme set to {new_theme}\n")

#     def start_download(self):
#         """Start download in a new thread"""
#         url = self.url_entry.get().strip()
#         if not url:
#             messagebox.showerror("Error", "Please enter a YouTube URL")
#             return
            
#         if self.active_download_thread and self.active_download_thread.is_alive():
#             messagebox.showwarning("Warning", "A download is already in progress")
#             return
            
#         if self.use_aria2c_var.get() and not os.path.exists(aria2c_path):
#             messagebox.showerror("Error", f"aria2c not found at {aria2c_path}")
#             return
            
#         self.should_cancel = False
#         self.is_paused = False
#         self.update_status("🔄 Testing available formats...\n")
#         self.active_download_thread = threading.Thread(target=self.run_download, args=(url,), daemon=True)
#         self.active_download_thread.start()
        
#         self.download_button.configure(state="disabled")
#         self.pause_button.configure(state="normal")
#         self.cancel_button.configure(state="normal")

#     def run_download(self, url):
#         """Main download execution"""
#         try:
#             # Create temp directory for aria2c temp files
#             self.temp_dir = tempfile.mkdtemp()
#             free_space = shutil.disk_usage(self.temp_dir).free / (1024**3)
#             self.update_status(f"Created temp dir: {self.temp_dir} (Free space: {free_space:.2f} GB)\n")
            
#             # Prepare command
#             command = self.build_command(url, yt_dlp_path)
#             self.update_status(f"Executing: {' '.join(command)}\n")
            
#             # Start process
#             creationflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
#             self.download_process = subprocess.Popen(
#                 command,
#                 stdout=subprocess.PIPE,
#                 stderr=subprocess.PIPE,
#                 text=True,
#                 encoding='utf-8',
#                 errors='replace',
#                 bufsize=1,
#                 universal_newlines=True,
#                 creationflags=creationflags
#             )
            
#             # Read output line by line
#             start_time = time.time()
#             while True:
#                 if self.should_cancel:
#                     break
                    
#                 line = self.download_process.stdout.readline()
#                 if not line:
#                     if self.download_process.poll() is not None:
#                         break
#                     continue
                
#                 self.output_queue.put(line.strip())
#                 if time.time() - start_time > 3:  # Log speed every 3 seconds
#                     self.update_status(f"Current speed: {self.speed_label.cget('text')}\n")
#                     start_time = time.time()
#                 time.sleep(0.005)  # Reduced sleep for faster processing
                
#             # Check stderr for errors
#             stderr_output = self.download_process.stderr.read()
#             if stderr_output:
#                 self.output_queue.put(f"⚠️ stderr: {stderr_output}")
                
#             # Check result
#             return_code = self.download_process.poll()
#             if return_code == 0:
#                 self.output_queue.put("✅ Download completed successfully!")
#                 self.log_history(url, self.download_path)
#             else:
#                 self.output_queue.put(f"❌ Download failed with code {return_code}")
                
#         except Exception as e:
#             self.output_queue.put(f"❌ Error: {str(e)}")
#         finally:
#             self.cleanup_download()

#     def build_command(self, url, ytdlp_path):
#         """Build the download command array with optimized settings"""
#         mode = self.option_menu.get()
#         quality = self.quality_menu.get()
#         connections = int(self.connections_slider.get())
        
#         playlist_flag = "--yes-playlist" if "Playlist" in mode else "--no-playlist"
#         format_flag = self.get_format_flag(quality)
        
#         output_template = (
#             os.path.join(self.download_path, "%(playlist_title)s", "%(playlist_index)s - %(title)s.%(ext)s")
#             if "Playlist" in mode else os.path.join(self.download_path, "%(title)s.%(ext)s")
#         )
        
#         output_template = output_template.replace('"', '\\"')
        
#         # Optimized aria2c arguments
#         aria2c_args = (
#             f'-x{connections} -s{connections} -j8 -k1M '
#             f'--file-allocation=none --console-log-level=debug '
#             f'--allow-overwrite=true --auto-file-renaming=false '
#             f'--optimize-concurrent-downloads=true '
#             f'--max-overall-download-limit=0 '
#             f'--min-split-size=1M '
#             f'--disk-cache=256M '
#             f'--retry-wait=1 '
#             f'--max-tries=15 '
#             f'--async-dns=false '
#             f'--check-integrity=true'
#         )
        
#         downloader_args = (
#             ['--external-downloader', 'aria2c', '--external-downloader-args', aria2c_args]
#             if self.use_aria2c_var.get() else []
#         )
        
#         return [
#             ytdlp_path,
#             '--ignore-errors',
#             '--retries', '10',  # Increased retries
#             '--socket-timeout', '5',  # Faster timeout
#             '--concurrent-fragments', str(max(1, connections)),
#             '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',  # Updated user-agent
#             '--no-check-certificate',
#             playlist_flag,
#             *format_flag,
#             '--merge-output-format', 'mp4',
#             '--ffmpeg-location', ffmpeg_path,
#             *downloader_args,
#             '--embed-subs',
#             '--embed-metadata',
#             '-o', output_template,
#             url
#         ]

#     def process_output(self):
#         """Process output from the queue"""
#         try:
#             while not self.output_queue.empty():
#                 line = self.output_queue.get_nowait()
                
#                 self.status_box.configure(state="normal")
#                 self.status_box.insert("end", line + "\n")
#                 self.status_box.see("end")
#                 self.status_box.configure(state="disabled")
                
#                 if line.startswith("[download]"):
#                     self.parse_progress(line)
                    
#         except queue.Empty:
#             pass
            
#         self.after(200, self.process_output)  # Increased interval to reduce CPU usage

#     def parse_progress(self, line):
#         """Parse download progress information"""
#         try:
#             if "%" in line and "of" in line:
#                 percent_str = line.split("%")[0].split()[-1]
#                 if percent_str.replace(".", "").isdigit():
#                     percent = float(percent_str)
#                     self.progress_bar.set(percent / 100)
                
#             if "at" in line and "ETA" in line:
#                 speed = line.split("at")[1].split("ETA")[0].strip()
#                 self.speed_label.configure(text=f"Speed: {speed}")
                
#             if "ETA" in line:
#                 eta = line.split("ETA")[1].strip()
#                 self.eta_label.configure(text=f"ETA: {eta}")
                
#             if "of" in line and "at" in line:
#                 size = line.split("of")[1].split("at")[0].strip()
#                 self.size_label.configure(text=f"Size: {size}")
                
#         except Exception as e:
#             self.update_status(f"⚠️ Error parsing progress: {str(e)}\n")

#     def toggle_pause(self):
#         """Toggle pause/resume state"""
#         if self.is_paused:
#             self.resume_download()
#         else:
#             self.pause_download()

#     def pause_download(self):
#         """Pause the active download"""
#         if self.download_process and not self.is_paused:
#             self.is_paused = True
#             if os.name == 'nt':
#                 self.download_process.send_signal(signal.CTRL_BREAK_EVENT)
#             else:
#                 self.download_process.send_signal(signal.SIGSTOP)
#             self.pause_button.configure(text="▶️ Resume")
#             self.update_status("⏸️ Download paused\n")

#     def resume_download(self):
#         """Resume the paused download"""
#         if self.download_process and self.is_paused:
#             self.is_paused = False
#             if os.name == 'nt':
#                 self.download_process.send_signal(signal.CTRL_CONTINUE_EVENT)
#             else:
#                 self.download_process.send_signal(signal.SIGCONT)
#             self.pause_button.configure(text="⏸️ Pause")
#             self.update_status("▶️ Download resumed\n")

#     def cancel_download(self):
#         """Cancel the active download"""
#         if messagebox.askyesno("Confirm", "Are you sure you want to cancel the download?"):
#             self.should_cancel = True
#             if self.download_process:
#                 self.download_process.terminate()
#                 try:
#                     self.download_process.wait(timeout=3)  # Wait for graceful termination
#                 except subprocess.TimeoutExpired:
#                     self.download_process.kill()  # Force kill if needed
#             self.update_status("❌ Download cancelled\n")
#             self.cleanup_download()

#     def cleanup_download(self):
#         """Clean up download resources"""
#         if self.download_process:
#             try:
#                 self.download_process.terminate()
#                 self.download_process.wait(timeout=5)
#             except subprocess.TimeoutExpired:
#                 self.download_process.kill()
#             self.download_process = None
            
#         if self.temp_dir and os.path.exists(self.temp_dir):
#             try:
#                 shutil.rmtree(self.temp_dir, ignore_errors=True)
#                 self.update_status(f"Cleaned up temp dir: {self.temp_dir}\n")
#             except Exception as e:
#                 self.update_status(f"⚠️ Error cleaning temp dir: {str(e)}\n")
#             self.temp_dir = None
            
#         self.cleanup_temp_files()
#         self.reset_ui()

#     def cleanup_temp_files(self):
#         """Remove temporary download files"""
#         try:
#             for file in os.listdir(self.download_path):
#                 if file.endswith((".aria2", ".part")):
#                     os.remove(os.path.join(self.download_path, file))
#         except Exception as e:
#             self.update_status(f"⚠️ Error cleaning temp files: {str(e)}\n")

#     def reset_ui(self):
#         """Reset UI to default state"""
#         self.download_button.configure(state="normal")
#         self.pause_button.configure(state="disabled", text="⏸️ Pause")
#         self.cancel_button.configure(state="disabled")
#         self.progress_bar.set(0)
#         self.speed_label.configure(text="Speed: -")
#         self.eta_label.configure(text="ETA: -")
#         self.size_label.configure(text="Size: -")

#     def get_format_flag(self, quality):
#         """Return format flags based on quality selection"""
#         if quality == "Audio Only":
#             return ["-f", "bestaudio[ext=m4a]"]
#         elif quality == "Best":
#             return ["-f", "bestvideo[vcodec^=avc1][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]"]
#         else:
#             height = quality[:-1]
#             return ["-f", f"bestvideo[vcodec^=avc1][height<={height}][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]"]

#     def update_status(self, message):
#         """Thread-safe status updates"""
#         self.output_queue.put(message)

#     def log_history(self, url, path):
#         """Log successful downloads"""
#         try:
#             os.makedirs(os.path.dirname(resource_path(DOWNLOAD_HISTORY_FILE)), exist_ok=True)
#             with open(resource_path(DOWNLOAD_HISTORY_FILE), "a", encoding="utf-8") as log:
#                 log.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {url} → {path}\n")
#         except Exception as e:
#             self.update_status(f"⚠️ Error writing to history: {str(e)}\n")

#     def choose_folder(self):
#         """Set download directory"""
#         folder_selected = filedialog.askdirectory(initialdir=self.download_path)
#         if folder_selected:
#             self.download_path = folder_selected
#             self.update_status(f"📂 Download folder set to: {self.download_path}\n")

#     def on_closing(self):
#         """Clean up when window closes"""
#         if self.download_process:
#             try:
#                 self.download_process.terminate()
#                 self.download_process.wait(timeout=5)
#             except subprocess.TimeoutExpired:
#                 self.download_process.kill()
#         if self.temp_dir and os.path.exists(self.temp_dir):
#             try:
#                 shutil.rmtree(self.temp_dir, ignore_errors=True)
#             except Exception as e:
#                 self.update_status(f"⚠️ Error cleaning temp dir: {str(e)}\n")
#         self.destroy()

# if __name__ == "__main__":
#     if "--version" in sys.argv or "--help" in sys.argv:
#         print(f"YouTube Downloader {VERSION}" if "--version" in sys.argv else "Usage: yt-downloader [--version] [--help]")
#         sys.exit(0)
#     else:
#         app = YTDownloaderApp()
#         app.protocol("WM_DELETE_WINDOW", app.on_closing)
#         app.mainloop()
