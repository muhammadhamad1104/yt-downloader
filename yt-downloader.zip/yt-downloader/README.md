## 📥 YouTube Downloader GUI App
A powerful and elegant YouTube video & playlist downloader built with Python — featuring:

1. 🎬 Single video or full playlist download

2. 💾 High-quality downloads using yt-dlp, aria2c, ffmpeg

3. 🎨 Light/Dark mode switch

4. ⏯️ Pause / Resume / Cancel support

5. 📁 Custom download folder selection

6. 🕘 Download history log

7. 🪟 Modern GUI using customtkinter

8. 📦 Portable .exe version (no installation required)


## 🔧 Installation (For Developers)
1. Clone the Repository

git clone https://github.com/your-username/youtube-downloader-gui.git

cd yt-downloader

2. Install Requirements

pip install -r requirements.txt

3. Run the App

python main.py

## ⚠️NOTE: Your project **must be cloned to `C:/yt-downloader`** for packaging to work correctly.

## ✅ Step-by-Step: After Code Changes
Make changes in main.py or any other part of your app (e.g., assets, logic).

Rebuild the app using this command:

pyinstaller --noconsole --onefile --add-data "bin;bin" --add-data "assets;assets" --add-data "history;history" --icon=assets/icon.ico yt-downloader.py

## 📦 Portable .exe Version (No Python Required)
You can find the .exe in the Releases section.

## ✅ Features:
1. Just double-click the .exe

2. No Python or dependencies needed

3. All tools (yt-dlp, aria2c, ffmpeg) are pre-bundled in the app

## ⚙️ How It Works
1. yt-dlp handles YouTube downloads

2. aria2c is used for external downloading (multi-threaded speed boost)

3. ffmpeg merges video and audio

4. customtkinter powers the modern GUI


## 🛠 Add Executable to PATH (Optional)
If you want to run the .exe from any location via the terminal:

1. Copy the built .exe file from dist/ to a permanent location (e.g., C:\Tools\yt-downloader.exe)
2. Add that folder to your system environment variables:
On Windows:
Press Win + S → Search for "Environment Variables" → Click "Edit the system environment variables"

In System Properties → Click "Environment Variables"

Under System Variables → Select Path → Click Edit

Click New, and add the path where your .exe is located (e.g., C:\Tools)

Click OK and restart any terminal